﻿========================================================================
LUMA AI Inference Server (Node 3) — Defense Mastery (Academic Prep)
คู่มือการใช้งานสื่อการเรียนรู้เตรียมสอบปากเปล่าสำหรับฝ่าย AI Server
========================================================================
1. ดับเบิลคลิกเปิดไฟล์ index.html ผ่าน Google Chrome หรือเบราว์เซอร์ใดก็ได้
2. ใช้งานแบบ Standalone Offline 100%
3. ครอบคลุม 39 ฟังก์ชันซอร์สโค้ดจริง (รวม prompt_builder.py, server.py, queue_manager.py, forge_client.py, image_utils.py, gpu_monitor.py)
4. แบบฝึกซ้อมสอบปากเปล่า 12 ข้อ พร้อมห้องแล็บคณิตศาสตร์ VAE Downsampling และ WebP Compression
